from PIL import Image

sourcefile = "eberhard.jpg"

img = Image.open(sourcefile)

targetHeight = 1280
factor = img.height / 1280


img_resize = img.resize(
    (int(img.width / factor), int(img.height / factor)), Image.LANCZOS
)
img_resize.save("(resize)" + sourcefile)
